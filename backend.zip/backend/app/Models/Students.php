<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\Students
 *
 * @property int $id
 * @property string $idnumber
 * @property string $name
 * @property string $gender
 * @property string $email
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|Students newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Students newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Students query()
 * @method static \Illuminate\Database\Eloquent\Builder|Students whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Students whereEmail($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Students whereGender($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Students whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Students whereIdnumber($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Students whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Students whereUpdatedAt($value)
 * @mixin \Eloquent
 */
class Students extends Model
{
    use HasFactory;

    protected $fillable = [
        'idnumber','name','gender','email'
    ];
}
