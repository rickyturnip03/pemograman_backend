<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Http\Resources\StudentResource;
use App\Models\Students;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $student = Students::all();

        return new StudentResource(true,'Data Mahasiswa !' , $student);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'idnumber' => 'required|unique:students,idnumber',
            'name' => 'required',
            'gender' => 'required',
            'email' => 'required|email|unique:students,email'
        ]);

        if($validator->fails()){
            return response()->json($validator->errors(),422);
        }else{
            $students = Students::created([
                'idnumber' => $request->idnumber,
                'name' => $request->name,
                'gender' => $request->gender,
                'email' => $request->email,
            ]);

            return new StudentResource(true, 'Data berhasil tersimpan !', $students);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $student = Students::find($id);

        if($student){
            return new StudentResource(true, 'Data ditemukan !', $student);
        } else {
            return response()->json([
                'message' => 'Data tidak ditemukan !'
            ], 422);
        }
        }



    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'idnumber' => 'required|unique:students,idnumber',
            'name' => 'required',
            'gender' => 'required',
            'email' => 'required|email|unique:students,email'
        ]);

        if($validator->fails()){
            return response()->json($validator->errors(),422);
        }else{
            $students = Students::find($id);

            if($students){
                $students->name = $request->name;
                $students->gender = $request->gender;
                $students->email = $request->email;
                $students->save();

                return new StudentResource(true, 'Data berhasil di update !', $students);
            }else{
                return response()->json([
                    'message' => 'Data tidak ditemukan !'
                ]);
            }
            }
        }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $students = Students::find($id);

        if($students){
            $students->delete();

            return new StudentResource(true, 'Data berhasil di hapus !', '');
        }else{
            return response()->json([
                'message' => 'Data tidak ditemukan !'
            ]);
        }
    }
}


